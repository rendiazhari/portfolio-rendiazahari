var typed = new Typed(".text", {
    strings: ["Computer Science Student", "Frontend Developer", "Web Developer"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});
useEffect(() => {
  const script = document.createElement("script");
  script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js";
  script.async = true;
  script.setAttribute("data-ad-client", "YOUR_CLIENT_ID");
  document.head.appendChild(script);
}, []);
